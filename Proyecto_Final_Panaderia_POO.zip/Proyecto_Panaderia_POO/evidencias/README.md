# Evidencias

Colocar aquí las capturas de las cuatro pruebas solicitadas por el docente.

Pruebas sugeridas:
1. Agregar producto correctamente.
2. Buscar un producto por parte del nombre.
3. Intentar vender más unidades que el stock disponible (error controlado).
4. Registrar una venta y observar el descuento por volumen y el reporte.
