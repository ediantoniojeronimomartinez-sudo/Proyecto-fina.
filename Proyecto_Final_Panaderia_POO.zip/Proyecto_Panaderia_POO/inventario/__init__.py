"""Paquete principal del sistema de inventario de la panadería."""
